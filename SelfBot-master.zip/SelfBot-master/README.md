Line Self Bot by ♠Mē

Install terlebih dahulu
- Termux (Playstore)
- Termux api (Playstore)

Kode Tutorial selft bot Line♠Mē

Kode Tutorial :
1. pkg install python2 -y;
2. pkg install git -y;
3. git clone https://github.com/Azwieen/SelfBot
4. pip2 install thrift==0.9.3
5. pkg install rsa
6. pip2 install requests
7. pip2 install rsa
8. ls
9. cd SelfBot
10. ls
11. python2 me.py

untuk menjalankan lagi/ambil link lg cukup pake perintah ini

sh url.sh /SelfBot

atau

cd SelfBot
python2 me.py

copas linknya,, lalu klik link,, klik lg log in

keyword : Untuk menggunakannya, anda harus mengetik perintah set terlebih dahulu di dalam grup untuk memastikan berhasil atau sukses akan langsung di respon, setelah anda mengetikan perintah set, barulah command atau perintah yang lain bisa dijalankan. Berikut command command atau perintah selfbot beserta keterangannya
1. set [untuk mengatur atau men-set read point di sebuah grup]
2. cek sider [untuk melihat siders]
3. me [untuk mengirimkan contact diri sendiri / pemasang selfbot tersebut]
4. mid [untuk melihat id diri sendiri / pemasang selfbot tersebut]
5. ginfo [untuk melihat info sebuah grup
6. gid [untuk melihat id grup]
7. time [untuk melihat waktu]
8. open [untuk membuka link qr code di sebuah grup] 9. close [untuk menutup link qr code di sebuah grup]
10. url [untuk mengetahui url sebuah grup]
11. kick: [untuk mengeluarkan anggota grup dengan syarat hanya 1 anggota, tergantung kita memasukan nama target tersebut] Perintah atau command command di atas tidak bisa dilakukan jika anda belum mengetik set di grup yang ingin anda pasang selfbot diri anda sendiri.