cd SelfBot
python2 me.py